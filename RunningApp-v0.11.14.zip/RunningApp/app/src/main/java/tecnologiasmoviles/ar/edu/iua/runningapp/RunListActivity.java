package tecnologiasmoviles.ar.edu.iua.runningapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import tecnologiasmoviles.ar.edu.iua.runningapp.model.RunData;
import tecnologiasmoviles.ar.edu.iua.runningapp.util.RunJSONParser;

public class RunListActivity extends AppCompatActivity {

    List<RunData> runData = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_run_list);

        ListView list = findViewById(R.id.listView);
        CustomListAdapter customListAdapter =  new CustomListAdapter();

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                GoToDetailView(view,position);
            }
        });

        list.setAdapter(customListAdapter);
    }

    public void GoToDetailView(View view, int position){

        Intent detailIntent = new Intent (this,RunDetailActivity.class );
        detailIntent.putExtra("time",runData.get(position).getTime());
        detailIntent.putExtra("length",runData.get(position).getLength());
        detailIntent.putExtra("speed",runData.get(position).getSpeed());
        //detailIntent.putExtra("coords",runData.get(position).getCoordinates());

        startActivity(detailIntent);

    }

    private class CustomListAdapter extends BaseAdapter {

        CustomListAdapter(){
            InputStream jsonInput = getResources().openRawResource(R.raw.runs_data);

            RunJSONParser runsJSONParser = new RunJSONParser();
            try{
                runData = runsJSONParser.getJsonStream(jsonInput);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getCount() {
            return runData.size();
        }

        @Override
        public Object getItem(int position) {
            return runData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {

            if(view==null){
                view=getLayoutInflater().inflate(R.layout.list_cell,viewGroup,false);
            }

            /*ImageView mapSummary = view.findViewById(R.id.mapSummary);
            int idCover = getResources().getIdentifier(songData.get(position).getCover(),"drawable",getPackageName());
            albumCover.setBackgroundResource(idCover);*/

            TextView title = view.findViewById(R.id.runSummary);
            title.setText(runData.get(position).getLength() + " Metros - " + runData.get(position).getTime() + " minutos");

            return view;
        }
    }
}
