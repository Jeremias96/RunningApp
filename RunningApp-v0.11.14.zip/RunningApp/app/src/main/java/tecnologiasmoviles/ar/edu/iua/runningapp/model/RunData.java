package tecnologiasmoviles.ar.edu.iua.runningapp.model;

import com.google.android.gms.maps.model.LatLng;

import java.util.List;

public class RunData {

    private int id;
    private double time;
    private double length;
    private double speed;   //minutos/kilometro
    private List<LatLng> coordinates;

    public RunData(){

    }

    public RunData(int id, double time, double length, double speed, List<LatLng> coordinates) {
        this.id = id;
        this.time = time;
        this.length = length;
        this.speed = speed;
        this.coordinates = coordinates;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public List<LatLng> getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(List<LatLng> coordinates) {
        this.coordinates = coordinates;
    }
}
