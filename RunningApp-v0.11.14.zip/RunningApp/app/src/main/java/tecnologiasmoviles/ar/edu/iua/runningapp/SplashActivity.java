package tecnologiasmoviles.ar.edu.iua.runningapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Button startBtn = findViewById(R.id.startButton);
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoToRegisterView(v);
            }
        });
    }

    public void GoToRegisterView (View view){
        Intent registerIntent = new Intent (this,RunRegisterActivity.class );
        startActivity(registerIntent);
    }
}
