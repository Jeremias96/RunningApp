package tecnologiasmoviles.ar.edu.iua.runningapp;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsFragment extends Fragment implements OnMapReadyCallback {

    MapView mapView;
    GoogleMap mMap;
    View mView;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_map,container,false);
        return mView;
        //return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mapView =  (MapView) mView.findViewById(R.id.mapView);

        if(mapView !=null) {
            mapView.onCreate(savedInstanceState);
            mapView.onResume();
            mapView.getMapAsync(this);
        }

    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        MapsInitializer.initialize(getContext());
        mMap = googleMap;
        LatLng cordoba = new LatLng(-31.25, -64.11);
        mMap.addMarker(new MarkerOptions().position(cordoba).title("Marcador en Cordoba"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(cordoba));

    }

    public void addMarker(double lat, double lng) {
        LatLng newPosition = new LatLng(lat, lng);
        mMap.addMarker(new MarkerOptions().position(newPosition).title("Marcado hecho por onLocationResult"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(newPosition));
    }

    @SuppressLint("MissingPermission")
    public void setMyLocationEnabled(boolean b) {
        mMap.setMyLocationEnabled(true);
    }
}
