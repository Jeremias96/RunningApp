package tecnologiasmoviles.ar.edu.iua.runningapp.util;

import android.util.JsonReader;

import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import tecnologiasmoviles.ar.edu.iua.runningapp.model.RunData;

public class RunJSONParser {

    public List<RunData> getJsonStream(InputStream i) throws IOException {
        List<RunData> list = null;
        JsonReader reader = new JsonReader(new InputStreamReader(i));
        try {
            list = getDataArray(reader);
        }finally {
            reader.close();
        }
        return list;
    }

    private List<RunData> getDataArray(JsonReader reader) throws IOException {
        List<RunData> list = new ArrayList<RunData>();
        reader.beginArray();
        while(reader.hasNext()){
            list.add(getData(reader));
        }
        reader.endArray();

        return list;
    }

    private RunData getData(JsonReader reader) throws IOException{
        RunData sd = new RunData();
        reader.beginObject();
        while (reader.hasNext()){
            switch (reader.nextName()){
                case "id":
                    sd.setId(reader.nextInt());
                    break;
                case "time":
                    sd.setTime(reader.nextDouble());
                    break;
                case "length":
                    sd.setLength(reader.nextDouble());
                    break;
                case "speed":
                    sd.setSpeed(reader.nextDouble());
                    break;
                case "coordinates":
                    sd.setCoordinates(ParseCoordinates(reader));
                    break;
                default:
                    reader.skipValue();
                    break;
            }
        }
        reader.endObject();
        return sd;
    }

    private List<LatLng> ParseCoordinates(JsonReader reader) throws IOException {
        Double lat = 0d;
        Double lng = 0d;
        List<LatLng> coords = new ArrayList<LatLng>();
        reader.beginArray();
        while (reader.hasNext()){
            reader.beginObject();
            while (reader.hasNext()) {
                switch (reader.nextName()) {
                    case "lat":
                        lat = reader.nextDouble();
                        break;
                    case "lng":
                        lng = reader.nextDouble();
                        break;
                    default:
                        reader.skipValue();
                        break;
                }
            }
            reader.endObject();
            coords.add(new LatLng(lat, lng));
        }
        reader.endArray();
        return coords;
    }

}
