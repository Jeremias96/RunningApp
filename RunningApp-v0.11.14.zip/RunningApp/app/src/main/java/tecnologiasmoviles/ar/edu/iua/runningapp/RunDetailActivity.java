package tecnologiasmoviles.ar.edu.iua.runningapp;

import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RunDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_run_detail);

        /*Intent detailIntent = getIntent();

        Resources res = getResources();
        Double time  = detailIntent.getDoubleExtra("time", 0d);
        Double length  = detailIntent.getDoubleExtra("length", 0d);
        Double speed  = detailIntent.getDoubleExtra("speed", 0d);*/
    }
}
