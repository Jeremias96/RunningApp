package tecnologiasmoviles.ar.edu.iua.runningapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//import android.widget.Chronometer;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import tecnologiasmoviles.ar.edu.iua.runningapp.util.Chronometer;

public class RunRegisterActivity extends AppCompatActivity {

    /*private String[] mListTitles = new String[2];
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;*/

    //TODO
    //Ritmo
    //Limitar guardado de puntos (por angulo/bearing)
    //Formar poligono cuando termina recorrido
    //Guardar datos en JSON para poder ver en la lista
    //7. Implementar menú de opciones.
    //8. Implementar Audio Player.
    //9. Acceder a la librería multimedia del dispositivo.
    //10. Implementar Google Maps, dentro del mismo mostrar recorrido realizado por el usuario.
    //11. Implementar notificación con mensaje motivacional si el usuario no corre durante cierto tiempo.
    //12. Implementar compartir registro a través de Facebook.

    LocationCallback mLocationCallback;
    LocationRequest mLocationRequest;
    FusedLocationProviderClient mFusedProviderLocationClient;
    FragmentManager fm;
    MapsFragment mapFragment;
    private static final int FINE_LOCATION_PERMISSION_REQUEST = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_run_register_wmap);

        createLocationRequest();
        mFusedProviderLocationClient = LocationServices.getFusedLocationProviderClient(this);

        fm = getSupportFragmentManager();
        mapFragment = (MapsFragment) fm.findFragmentById(R.id.mapFragment);

        final TextView textViewTiempo = findViewById(R.id.textViewTiempo);
        final TextView textViewDistancia = findViewById(R.id.textViewDistancia);
        final TextView valorDistancia = findViewById(R.id.valorDistancia);
        final TextView textViewRitmo = findViewById(R.id.textViewRitmo);
        final TextView valorRitmo = findViewById(R.id.valorRitmo);
        final Chronometer chrono = (Chronometer)findViewById(R.id.cronometro);
        final float[] results = new float[3];
        final Double[] lastLat = new Double[1];
        final Double[] lastLong = new Double[1];
        final float[] lastBearing = {0};
        final long[] lastTime = {0};
        final float[] ritmo = {0};
        final boolean[] first = {true};
        final float[] distance = {0};

        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (first[0] == true) {
                        lastLat[0] = location.getLatitude();
                        lastLong[0] = location.getLongitude();
                        lastBearing[0] = location.getBearing();
                        lastTime[0] = chrono.getTimeElapsed();
                    }
                    Location.distanceBetween(lastLat[0], lastLong[0], location.getLatitude(), location.getLongitude(), results);
                    distance[0] = distance[0] + results[0];
                    valorDistancia.setText(String.format("%.2f", distance[0] / 1000));
                    //textViewRitmo.setText("" + location.getBearing());
                    //textViewDistancia.setText("" + chrono.getTimeElapsed());
                    //textViewRitmo.setText("" + results[0]);
                    ritmo[0] = ((chrono.getTimeElapsed() - lastTime[0]) / 60000f) / (results[0]/1000f);
                    valorRitmo.setText(String.format("%.2f", ritmo[0]));
                    //Si la diferencia entre los angulos es mayor a algo (ej: 45 grados), hacer lo siguiente
                    if ((lastBearing[0] - results[1]) > 45)
                        mapFragment.addMarker(location.getLatitude(), location.getLongitude());
                    mapFragment.setMyLocationEnabled(true);
                    lastLat[0] = location.getLatitude();
                    lastLong[0] = location.getLongitude();
                    lastBearing[0] = results[1];
                    lastTime[0] = chrono.getTimeElapsed();
                    first[0] = false;
                }
            }
        };

        final Button startRunBtn = findViewById(R.id.startRunButton);
        final boolean[] running = {false};
        startRunBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mapFragment = findMapFragment();
                if (running[0] == false){
                    startRunBtn.setText("Parar");
                    startLocationsUpdates();
                    chrono.setBase(SystemClock.elapsedRealtime());
                    chrono.setBase(SystemClock.elapsedRealtime() - chrono.getTimeElapsed());
                    chrono.start();
                    distance[0] = 0;
                    first[0] = true;
                    valorDistancia.setText("" + distance[0]);
                    running[0] = true;
                } else {
                    startRunBtn.setText("Empezar!");
                    stopLocationUpdates();
                    chrono.stop();
                    running[0] = false;
                }
            }
        });

        Button listBtn = findViewById(R.id.listButton);
        listBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoToListView(v);
            }
        });

        //AudioPlayerFragment newInstance;
        /*mListTitles[0] = "Registrar Actividad";
        mListTitles[1] = "Ver lista de Actividades";
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (ListView) findViewById(R.id.left_drawer);

        // Set the adapter for the list view
        mDrawerList.setAdapter(new ArrayAdapter<String>(this,
                R.layout., mListTitles));
        // Set the list's click listener
        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //GoToDetailView(view,position);
            }
        });*/
    }

    private MapsFragment findMapFragment() {
        return (MapsFragment) fm.findFragmentById(R.id.mapFragment);
    }

    void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setFastestInterval(2000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    void startLocationsUpdates() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, FINE_LOCATION_PERMISSION_REQUEST);
        }
        mFusedProviderLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, null);
    }

    void stopLocationUpdates(){
        mFusedProviderLocationClient.removeLocationUpdates(mLocationCallback);
    }

    public void GoToListView (View view){
        Intent listIntent = new Intent (this,RunListActivity.class );
        startActivity(listIntent);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults){
        switch (requestCode) {
            case FINE_LOCATION_PERMISSION_REQUEST:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //Toast.makeText(MainActivity.this, "Permission Granted!", Toast.LENGTH_SHORT).show();
                    //abrirCamara.setEnabled(true);
                    mapFragment.setMyLocationEnabled(true);
                } else {
                    //Toast.makeText(MainActivity.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }
        }
    }
}
